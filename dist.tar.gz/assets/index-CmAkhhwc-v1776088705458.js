typeof setImmediate=="function"?setImmediate:typeof scheduler=="object"&&typeof scheduler.postTask=="function"&&scheduler.postTask.bind(scheduler);
