// 管理后台云函数
// 处理所有后台管理相关的数据库操作
const cloudbase = require('@cloudbase/node-sdk')

const app = cloudbase.init({
  env: cloudbase.SYMBOL_CURRENT_ENV
})

const db = app.database()
const _ = db.command

/**
 * 主函数
 */
exports.main = async (event, context) => {
  const { action, collection, data, query, docId, options } = event
  
  console.log('管理后台请求:', { action, collection, docId })
  
  try {
    switch (action) {
      case 'list':
        return await handleList(collection, query, options)
      case 'get':
        return await handleGet(collection, docId)
      case 'add':
        return await handleAdd(collection, data)
      case 'update':
        return await handleUpdate(collection, docId, data)
      case 'delete':
        return await handleDelete(collection, docId)
      case 'batchDelete':
        return await handleBatchDelete(collection, query)
      case 'count':
        return await handleCount(collection, query)
      case 'aggregate':
        return await handleAggregate(collection, pipeline, options)
      default:
        return {
          code: 400,
          message: `未知的操作类型: ${action}`
        }
    }
  } catch (error) {
    console.error('管理后台操作失败:', error)
    return {
      code: 500,
      message: error.message || '操作失败',
      error: error
    }
  }
}

/**
 * 查询列表
 */
async function handleList(collection, query = {}, options = {}) {
  const { limit = 100, offset = 0, orderBy, order = 'asc', field } = options
  
  let dbQuery = db.collection(collection)
  
  // 应用查询条件
  if (query && Object.keys(query).length > 0) {
    dbQuery = dbQuery.where(query)
  }
  
  // 应用排序
  if (orderBy) {
    dbQuery = dbQuery.orderBy(orderBy, order)
  }
  
  // 应用字段过滤
  if (field) {
    dbQuery = dbQuery.field(field)
  }
  
  // 应用分页
  dbQuery = dbQuery.skip(offset).limit(limit)
  
  const result = await dbQuery.get()
  
  return {
    code: 0,
    message: '查询成功',
    data: result.data,
    total: result.data.length
  }
}

/**
 * 获取单个文档
 */
async function handleGet(collection, docId) {
  const result = await db.collection(collection).doc(docId).get()
  
  if (!result.data || result.data.length === 0) {
    return {
      code: 404,
      message: '文档不存在'
    }
  }
  
  return {
    code: 0,
    message: '查询成功',
    data: result.data[0]
  }
}

/**
 * 添加文档
 */
async function handleAdd(collection, data) {
  const addData = {
    ...data,
    _openid: data._openid || '{admin}',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  }
  
  const result = await db.collection(collection).add(addData)
  
  if (result.code) {
    return {
      code: result.code,
      message: result.message || '添加失败'
    }
  }
  
  return {
    code: 0,
    message: '添加成功',
    data: {
      id: result.id,
      ...addData
    }
  }
}

/**
 * 更新文档
 */
async function handleUpdate(collection, docId, data) {
  const updateData = {
    ...data,
    updatedAt: new Date().toISOString()
  }
  
  const result = await db.collection(collection).doc(docId).update(updateData)
  
  if (result.code) {
    return {
      code: result.code,
      message: result.message || '更新失败'
    }
  }
  
  return {
    code: 0,
    message: '更新成功',
    data: updateData
  }
}

/**
 * 删除文档
 */
async function handleDelete(collection, docId) {
  const result = await db.collection(collection).doc(docId).remove()
  
  if (result.code) {
    return {
      code: result.code,
      message: result.message || '删除失败'
    }
  }
  
  return {
    code: 0,
    message: '删除成功'
  }
}

/**
 * 批量删除
 */
async function handleBatchDelete(collection, query) {
  const result = await db.collection(collection).where(query).remove()
  
  if (result.code) {
    return {
      code: result.code,
      message: result.message || '批量删除失败'
    }
  }
  
  return {
    code: 0,
    message: '批量删除成功'
  }
}

/**
 * 统计数量
 */
async function handleCount(collection, query = {}) {
  let dbQuery = db.collection(collection)
  
  if (query && Object.keys(query).length > 0) {
    dbQuery = dbQuery.where(query)
  }
  
  const result = await dbQuery.count()
  
  return {
    code: 0,
    message: '统计成功',
    data: result.total
  }
}

/**
 * 聚合查询
 */
async function handleAggregate(collection, pipeline = [], options = {}) {
  let aggregate = db.collection(collection)
  
  pipeline.forEach(step => {
    const key = Object.keys(step)[0]
    const value = step[key]
    aggregate = aggregate[key](value)
  })
  
  const result = await aggregate.end()
  
  return {
    code: 0,
    message: '聚合查询成功',
    data: result.list || result.data || []
  }
}
